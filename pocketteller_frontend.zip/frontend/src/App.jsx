
function App() {
  return (
    <div className="p-6 text-center text-xl font-bold text-white bg-gray-800 min-h-screen">
      PocketTeller Dashboard (Frontend Starter)
    </div>
  );
}

export default App;
